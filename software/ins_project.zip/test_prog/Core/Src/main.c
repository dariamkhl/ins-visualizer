/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <math.h>
#include <stdio.h>
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define WGS84_A       6378137.0f
#define WGS84_E2      0.00669437999014f
#define EARTH_U       0.00007292115f
#define GRAVITY_G0    9.80665f
#define BMP580_I2C_ADDR   (0x46 << 1)
#define QMC5883L_ADDR 0x1A
#define MPU_ADDR      0xD0

#define DEG2RAD       0.01745329252f
#define RAD2DEG       57.2957795f
#define DEG2RAD_D     0.017453292519943295
#define RAD2DEG_D     57.29577951308232

#define MAHONY_KP            2.0f
#define MAHONY_KP_ALIGN      10.0f
#define DT_MAX               0.10f
#define ACCEL_DEADBAND       0.15f
#define STATIONARY_TIME_S    0.15f
#define VEL_DAMP_TAU_S       5.0f
#define GYRO_YAW_SIGN        1.0f
#define V_LIMIT_MS           150.0f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t buffer[14];

float accel_X, accel_Y, accel_Z;
float gyro_X, gyro_Y, gyro_Z;

float accel_offset_X = 0, accel_offset_Y = 0;
float accel_gain_Z = 1.0f;
float gyro_offset_X = 0, gyro_offset_Y = 0, gyro_offset_Z = 0;

float mahony_twoKp = 2.0f * MAHONY_KP;

float q0 = 1.0f, q1 = 0.0f, q2 = 0.0f, q3 = 0.0f;

float pitch, roll, yaw;
float yaw_ahrs;
uint32_t last_time = 0;

float accel_east, accel_north, accel_up;
float filtered_east = 0.0f;
float filtered_north = 0.0f;
float filtered_up = 0.0f;
float nav_e = 0.0f, nav_n = 0.0f;

float v_E = 0.0f;
float v_N = 0.0f;
float v_Up = 0.0f;

float w_xi = 0.0f, w_eta = 0.0f, w_zeta = 0.0f;

float R_E = 6378137.0f, R_N = 6378137.0f;

double latitude_rad  = 0.0;
double longitude_rad = 0.0;
double lat0_rad = 0.0, lon0_rad = 0.0;
double latitude_deg  = 0.0;
double longitude_deg = 0.0;
double latitude_deg_0  = 0.0;
double longitude_deg_0 = 0.0;

float local_x, local_y;

float altitude_baro = 0.0f;
float altitude_h = 0.0f;

float phi_dot = 0.0f;
float lambda_dot = 0.0f;
float altitude_dot = 0.0f;

int16_t mag_x = 0;
int16_t mag_y = 0;
int16_t mag_z = 0;
float heading_deg = 0.0f;

static float stationary_time = 0.0f;

static int16_t encoder_val = 0;

float mag_offset_x = -1843.0f;
float mag_offset_y = -256.5f;

float kalman_altitude = 0.0f;
float kalman_v_up     = 0.0f;

float P_00 = 1.0f, P_01 = 0.0f;
float P_10 = 0.0f, P_11 = 1.0f;

float Q_accel = 0.08f;
float R_baro  = 0.3f;

float kalman_yaw = 0.0f;
float P_yaw = 1.0f;

float Q_gyro = 0.005f;
float R_mag  = 0.5f;

uint8_t current_screen = 0;

volatile uint32_t diag_mpu_err = 0;
volatile uint32_t diag_i2c_recover = 0;
volatile uint32_t diag_fault_reset = 0;
volatile uint8_t  diag_last_reason = 0;
float diag_max_dt = 0.0f;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

volatile HAL_StatusTypeDef qmc_status = HAL_ERROR;
volatile HAL_StatusTypeDef check_write1 = HAL_ERROR;
volatile HAL_StatusTypeDef check_write2 = HAL_ERROR;

void I2C1_ClearBus(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitStruct.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);

    for (int i = 0; i < 9; i++) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
        HAL_Delay(1);
    }

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
    HAL_Delay(1);
}

/* ---------------------------- MPU6050 ---------------------------------- */

void MPU6050_Init(void)
{
    uint8_t d = 0x01;
    HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, 0x6B, I2C_MEMADD_SIZE_8BIT, &d, 1, 100);
    HAL_Delay(10);
    d = 0x03;
    HAL_I2C_Mem_Write(&hi2c1, MPU_ADDR, 0x1A, I2C_MEMADD_SIZE_8BIT, &d, 1, 100);
}

static HAL_StatusTypeDef MPU_ReadRaw(float *ax, float *ay, float *az,
                                     float *gx, float *gy, float *gz)
{
    if (HAL_I2C_Mem_Read(&hi2c1, MPU_ADDR, 0x3B, I2C_MEMADD_SIZE_8BIT, buffer, 14, 10) != HAL_OK)
        return HAL_ERROR;

    *ax = (int16_t)((buffer[0] << 8) | buffer[1]) / 16384.0f;
    *ay = (int16_t)((buffer[2] << 8) | buffer[3]) / 16384.0f;
    *az = (int16_t)((buffer[4] << 8) | buffer[5]) / 16384.0f;

    *gx = (int16_t)((buffer[8]  << 8) | buffer[9])  / 131.0f;
    *gy = (int16_t)((buffer[10] << 8) | buffer[11]) / 131.0f;
    *gz = (int16_t)((buffer[12] << 8) | buffer[13]) / 131.0f;
    return HAL_OK;
}

static HAL_StatusTypeDef Read_MPU6050(void)
{
    float ax, ay, az, gx, gy, gz;
    if (MPU_ReadRaw(&ax, &ay, &az, &gx, &gy, &gz) != HAL_OK)
        return HAL_ERROR;

    accel_X = ax - accel_offset_X;
    accel_Y = ay - accel_offset_Y;
    accel_Z = az;

    gyro_X = gx - gyro_offset_X;
    gyro_Y = gy - gyro_offset_Y;
    gyro_Z = gz - gyro_offset_Z;
    return HAL_OK;
}

void Calibrate_MPU6050(void)
{
    float sum_gx = 0, sum_gy = 0, sum_gz = 0;
    float sum_ax = 0, sum_ay = 0, sum_az = 0;
    int good = 0;

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);

    for (int i = 0; i < 200; i++)
    {
        float ax, ay, az, gx, gy, gz;
        if (MPU_ReadRaw(&ax, &ay, &az, &gx, &gy, &gz) == HAL_OK)
        {
            sum_ax += ax; sum_ay += ay; sum_az += az;
            sum_gx += gx; sum_gy += gy; sum_gz += gz;
            good++;
        }
        HAL_Delay(5);
    }


    if (good >= 100)
    {
        accel_offset_X = sum_ax / good;
        accel_offset_Y = sum_ay / good;

        gyro_offset_X = sum_gx / good;
        gyro_offset_Y = sum_gy / good;
        gyro_offset_Z = sum_gz / good;
    }

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
}

/* ---------------------------- QMC5883L --------------------------------- */

void QMC5883L_Init(void)
{
    uint8_t reg = 0;

    reg = 0x01;
    HAL_I2C_Mem_Write(&hi2c1, QMC5883L_ADDR, 0x0B, I2C_MEMADD_SIZE_8BIT, &reg, 1, 100);
    HAL_Delay(20);

    reg = 0x01;
    HAL_I2C_Mem_Write(&hi2c1, QMC5883L_ADDR, 0x0B, I2C_MEMADD_SIZE_8BIT, &reg, 1, 100);
    HAL_Delay(10);

    reg = 0x1D;
    qmc_status = HAL_I2C_Mem_Write(&hi2c1, QMC5883L_ADDR, 0x09, I2C_MEMADD_SIZE_8BIT, &reg, 1, 100);
    HAL_Delay(20);
}


HAL_StatusTypeDef QMC5883L_Read(int16_t *mx, int16_t *my, int16_t *mz, float *heading)
{
    uint8_t data[6] = {0};

    if (HAL_I2C_Mem_Read(&hi2c1, QMC5883L_ADDR, 0x00, I2C_MEMADD_SIZE_8BIT, data, 6, 10) != HAL_OK)
        return HAL_ERROR;

    int16_t x = (int16_t)((data[1] << 8) | data[0]);
    int16_t y = (int16_t)((data[3] << 8) | data[2]);
    int16_t z = (int16_t)((data[5] << 8) | data[4]);

    if (x == 0 && y == 0 && z == 0) return HAL_ERROR;

    *mx = x; *my = y; *mz = z;

    float fx = (float)x - mag_offset_x;
    float fy = (float)y - mag_offset_y;
    float fz = (float)z;

    float roll_rad  = roll  * DEG2RAD;
    float pitch_rad = pitch * DEG2RAD;

    float Xh = fx * cosf(pitch_rad) + fz * sinf(pitch_rad);
    float Yh = fx * sinf(roll_rad) * sinf(pitch_rad) + fy * cosf(roll_rad) - fz * sinf(roll_rad) * cosf(pitch_rad);

    if (isfinite(Xh) && isfinite(Yh))
    {
        float head = atan2f(Yh, Xh) * RAD2DEG;
        if (head < 0.0f) head += 360.0f;
        *heading = head;
    }
    return HAL_OK;
}

void Calibrate_QMC5883L(void)
{
    int16_t x_min = 32767, x_max = -32768;
    int16_t y_min = 32767, y_max = -32768;
    int good = 0;

    for (int i = 0; i < 500; i++)
    {
        int16_t raw_x = 0, raw_y = 0, raw_z = 0;
        float dummy_head = 0;

        if (QMC5883L_Read(&raw_x, &raw_y, &raw_z, &dummy_head) == HAL_OK)
        {
            if (raw_x < x_min) x_min = raw_x;
            if (raw_x > x_max) x_max = raw_x;
            if (raw_y < y_min) y_min = raw_y;
            if (raw_y > y_max) y_max = raw_y;
            good++;
        }
        HAL_Delay(20);
    }


    if (good > 100 && (x_max - x_min) > 200 && (y_max - y_min) > 200)
    {
        mag_offset_x = (float)(x_max + x_min) / 2.0f;
        mag_offset_y = (float)(y_max + y_min) / 2.0f;
    }
}

/* ---------------------------- Калман курса ----------------------------- */

void Yaw_Predict(float gyro_rate_z, float dt)
{
    kalman_yaw += gyro_rate_z * dt;
    if (kalman_yaw >= 360.0f) kalman_yaw -= 360.0f;
    if (kalman_yaw < 0.0f)    kalman_yaw += 360.0f;

    P_yaw += Q_gyro * dt;
}

void Yaw_Correct(float mag_heading)
{
    float diff = mag_heading - kalman_yaw;
    if (diff > 180.0f)  diff -= 360.0f;
    if (diff < -180.0f) diff += 360.0f;

    float K = P_yaw / (P_yaw + R_mag);
    kalman_yaw += K * diff;
    P_yaw = (1.0f - K) * P_yaw;

    if (kalman_yaw >= 360.0f) kalman_yaw -= 360.0f;
    if (kalman_yaw < 0.0f)    kalman_yaw += 360.0f;
}

/* ---------------------------- Калман высоты ---------------------------- */

void Altitude_Predict(float accel_up_m_s2, float dt)
{
    kalman_altitude += kalman_v_up * dt + 0.5f * accel_up_m_s2 * dt * dt;
    kalman_v_up     += accel_up_m_s2 * dt;

    P_00 += dt * (P_10 + P_01 + dt * P_11) + Q_accel * dt * dt;
    P_01 += dt * P_11;
    P_10 += dt * P_11;
    P_11 += Q_accel * dt;
}

void Altitude_Correct(float baro_alt)
{
    float y = baro_alt - kalman_altitude;
    float S = P_00 + R_baro;

    float K_0 = P_00 / S;
    float K_1 = P_10 / S;

    kalman_altitude += K_0 * y;
    kalman_v_up     += K_1 * y;

    float P00_temp = P_00;
    float P01_temp = P_01;

    P_00 -= K_0 * P00_temp;
    P_01 -= K_0 * P01_temp;
    P_10 -= K_1 * P00_temp;
    P_11 -= K_1 * P01_temp;
}

/* ---------------------------- Bluetooth -------------------------------- */

volatile uint8_t uart_tx_busy = 0;
char send_buffer[160];

void send_data_Bluetooth(void) {
    static uint32_t tx_start = 0;

    if (uart_tx_busy) {
        if (HAL_GetTick() - tx_start > 200) {
            HAL_UART_AbortTransmit_IT(&huart2);
            uart_tx_busy = 0;
        }
        return;
    }

    snprintf(send_buffer, sizeof(send_buffer),
             "%.6f,%.6f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f\n",
             latitude_deg, longitude_deg, altitude_h,
             v_E, v_N, v_Up, roll, pitch, yaw);

    uart_tx_busy = 1;
    tx_start = HAL_GetTick();
    if (HAL_UART_Transmit_IT(&huart2, (uint8_t*)send_buffer, strlen(send_buffer)) != HAL_OK) {
        uart_tx_busy = 0;
    }
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        uart_tx_busy = 0;
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART2) {
        uart_tx_busy = 0;
    }
}

/* ---------------------------- BMP580 ----------------------------------- */

void BMP580_Init(void)
{
    uint8_t reg = 0;

    reg = 0xB6;
    HAL_I2C_Mem_Write(&hi2c1, BMP580_I2C_ADDR, 0x7E, I2C_MEMADD_SIZE_8BIT, &reg, 1, 100);
    HAL_Delay(50);

    reg = 0x59;
    check_write1 = HAL_I2C_Mem_Write(&hi2c1, BMP580_I2C_ADDR, 0x36, I2C_MEMADD_SIZE_8BIT, &reg, 1, 100);

    reg = 0x1E;
    check_write2 = HAL_I2C_Mem_Write(&hi2c1, BMP580_I2C_ADDR, 0x37, I2C_MEMADD_SIZE_8BIT, &reg, 1, 100);

    HAL_Delay(50);
}

float BMP580_ReadPressure(void)
{
    uint8_t p_buf[3] = {0};

    if (HAL_I2C_Mem_Read(&hi2c1, BMP580_I2C_ADDR, 0x20, I2C_MEMADD_SIZE_8BIT, p_buf, 3, 100) == HAL_OK)
    {
        int32_t raw_press = ((int32_t)p_buf[2] << 16) |
                            ((int32_t)p_buf[1] << 8)  |
                             (int32_t)p_buf[0];

        if (raw_press & 0x00800000) {
            raw_press |= 0xFF000000;
        }

        if (raw_press != 0x000B8000 && raw_press != 0x007FFFFF && raw_press != 0) {
            return (float)raw_press / 64.0f;
        }
    }
    return 0.0f;
}

static float Pressure_To_Altitude(float pressure_pa)
{
    return 44330.0f * (1.0f - powf(pressure_pa / 101325.0f, 0.190295f));
}

/* ---------------------------- Махони ---------------------- */

static void Quaternion_From_Accel(void)
{
    float n = sqrtf(accel_X * accel_X + accel_Y * accel_Y + accel_Z * accel_Z);
    float r = 0.0f, p = 0.0f;

    if (isfinite(n) && n > 0.5f) {
        r = atan2f(accel_Y, accel_Z);
        p = atan2f(-accel_X, sqrtf(accel_Y * accel_Y + accel_Z * accel_Z));
    }

    float cr = cosf(r * 0.5f), sr = sinf(r * 0.5f);
    float cp = cosf(p * 0.5f), sp = sinf(p * 0.5f);

    q0 = cr * cp;
    q1 = sr * cp;
    q2 = cr * sp;
    q3 = -sr * sp;
}

void MahonyAHRSupdateIMU(float gx, float gy, float gz, float ax, float ay, float az, float dt)
{
    float recipNorm;
    float halfvx, halfvy, halfvz;
    float halfex, halfey, halfez;
    float qa, qb, qc;

    float a_norm = sqrtf(ax * ax + ay * ay + az * az);

    if (isfinite(a_norm) && fabsf(a_norm - 1.0f) < 0.25f) {
        recipNorm = 1.0f / a_norm;
        ax *= recipNorm;
        ay *= recipNorm;
        az *= recipNorm;

        halfvx = q1 * q3 - q0 * q2;
        halfvy = q0 * q1 + q2 * q3;
        halfvz = q0 * q0 - 0.5f + q3 * q3;

        halfex = (ay * halfvz - az * halfvy);
        halfey = (az * halfvx - ax * halfvz);
        halfez = (ax * halfvy - ay * halfvx);

        gx += mahony_twoKp * halfex;
        gy += mahony_twoKp * halfey;
        gz += mahony_twoKp * halfez;
    }

    gx *= (0.5f * dt); gy *= (0.5f * dt); gz *= (0.5f * dt);
    qa = q0; qb = q1; qc = q2;
    q0 += (-qb * gx - qc * gy - q3 * gz);
    q1 += (qa * gx + qc * gz - q3 * gy);
    q2 += (qa * gy - qb * gz + q3 * gx);
    q3 += (qa * gz + qb * gy - qc * gx);

    float qn = q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3;
    if (!isfinite(qn) || qn < 1e-6f) {
        Quaternion_From_Accel();
        diag_fault_reset++;
        diag_last_reason = 1;
    } else {
        recipNorm = 1.0f / sqrtf(qn);
        q0 *= recipNorm; q1 *= recipNorm; q2 *= recipNorm; q3 *= recipNorm;
    }

    float s = 2.0f * (q0 * q2 - q3 * q1);
    if (s > 1.0f)  s = 1.0f;
    if (s < -1.0f) s = -1.0f;

    roll     = atan2f(2.0f * (q0 * q1 + q2 * q3), 1.0f - 2.0f * (q1 * q1 + q2 * q2)) * RAD2DEG;
    pitch    = asinf(s) * RAD2DEG;
    yaw_ahrs = atan2f(2.0f * (q0 * q3 + q1 * q2), 1.0f - 2.0f * (q2 * q2 + q3 * q3)) * RAD2DEG;
}

static void Compute_Nav_Accel(void)
{
    float C11 = 1.0f - 2.0f * (q2 * q2 + q3 * q3);
    float C12 = 2.0f * (q1 * q2 - q0 * q3);
    float C13 = 2.0f * (q1 * q3 + q0 * q2);

    float C21 = 2.0f * (q1 * q2 + q0 * q3);
    float C22 = 1.0f - 2.0f * (q1 * q1 + q3 * q3);
    float C23 = 2.0f * (q2 * q3 - q0 * q1);

    float C31 = 2.0f * (q1 * q3 - q0 * q2);
    float C32 = 2.0f * (q2 * q3 + q0 * q1);
    float C33 = 1.0f - 2.0f * (q1 * q1 + q2 * q2);

    accel_east  = (C11 * accel_X + C12 * accel_Y + C13 * accel_Z)        * GRAVITY_G0;
    accel_north = (C21 * accel_X + C22 * accel_Y + C23 * accel_Z)        * GRAVITY_G0;
    accel_up    = (C31 * accel_X + C32 * accel_Y + C33 * accel_Z - 1.0f) * GRAVITY_G0;

    const float alpha = 0.4f;
    filtered_east  += alpha * (accel_east  - filtered_east);
    filtered_north += alpha * (accel_north - filtered_north);
    filtered_up    += alpha * (accel_up    - filtered_up);

    nav_e = (fabsf(filtered_east)  < ACCEL_DEADBAND) ? 0.0f : filtered_east;
    nav_n = (fabsf(filtered_north) < ACCEL_DEADBAND) ? 0.0f : filtered_north;
}

/* ---------------------------- Навигация -------------------------------- */

void Update_Earth_Radii(float phi, float *Rn, float *Re)
{
    float sin_phi = sinf(phi);
    float sin2_phi = sin_phi * sin_phi;
    float temp = sqrtf(1.0f - WGS84_E2 * sin2_phi);

    *Re = WGS84_A / temp;
    *Rn = (WGS84_A * (1.0f - WGS84_E2)) / (temp * temp * temp);
}

void Calculate_W_g(float v_east, float v_north, float h, float phi, float Re, float Rn,
                   float *w_x, float *w_e, float *w_z)
{
    float Re_h = Re + h;
    float Rn_h = Rn + h;

    *w_x = -v_north / Rn_h;
    *w_e =  v_east  / Re_h;
    *w_z = (v_east  / Re_h) * tanf(phi);
}

void Calculate_Coordinates(float v_E_, float v_N_, float h, float phi, float Re, float Rn,
                           float *phi_dot_, float *lambda_dot_, float *altitude_dot_)
{
    float Rn_h = Rn + h;
    float Re_h = Re + h;

    *phi_dot_ = v_N_ / Rn_h;

    float cos_phi = cosf(phi);
    if (fabsf(cos_phi) < 0.000001f) {
        cos_phi = 0.000001f;
    }

    *lambda_dot_ = v_E_ / (Re_h * cos_phi);
    *altitude_dot_ = v_Up;
}

void format_adaptive_float(char *buf, size_t buf_size, const char *prefix, float value)
{
    if (fabsf(value) < 10.0f) {
        snprintf(buf, buf_size, "%s%.1f", prefix, value);
    } else {
        snprintf(buf, buf_size, "%s%.0f", prefix, value);
    }
}

/* ---------------------------- Сброс и защита --------------------------- */

static void Reset_Estimators(void)
{
    Quaternion_From_Accel();

    v_E = 0.0f; v_N = 0.0f; v_Up = 0.0f;
    filtered_east = 0.0f; filtered_north = 0.0f; filtered_up = 0.0f;
    nav_e = 0.0f; nav_n = 0.0f;
    stationary_time = 0.0f;

    kalman_altitude = (isfinite(altitude_baro) && fabsf(altitude_baro) < 20000.0f) ? altitude_baro : 0.0f;
    kalman_v_up = 0.0f;
    P_00 = 1.0f; P_01 = 0.0f; P_10 = 0.0f; P_11 = 1.0f;
    altitude_h = kalman_altitude;

    kalman_yaw = isfinite(heading_deg) ? heading_deg : 0.0f;
    P_yaw = 1.0f;

    if (!isfinite(latitude_rad) || !isfinite(longitude_rad)) {
        latitude_rad  = lat0_rad;
        longitude_rad = lon0_rad;
    }
    last_time = HAL_GetTick();
}

static void Check_Health(void)
{
    uint8_t bad = 0;

    if (!isfinite(q0 + q1 + q2 + q3) || !isfinite(roll) || !isfinite(pitch)) bad = 1;
    else if (!isfinite(v_E) || !isfinite(v_N) || fabsf(v_E) > V_LIMIT_MS || fabsf(v_N) > V_LIMIT_MS) bad = 2;
    else if (!isfinite(latitude_rad) || !isfinite(longitude_rad)) bad = 3;
    else if (!isfinite(kalman_altitude) || !isfinite(kalman_v_up) || !isfinite(kalman_yaw) ||
             !isfinite(P_00) || !isfinite(P_11) || !isfinite(P_yaw) ||
             fabsf(kalman_altitude) > 20000.0f || fabsf(kalman_v_up) > V_LIMIT_MS) bad = 4;

    if (bad) {
        diag_last_reason = bad;
        diag_fault_reset++;
        Reset_Estimators();
    }
}

static void Recover_I2C(void)
{
    HAL_I2C_DeInit(&hi2c1);
    __HAL_RCC_I2C1_FORCE_RESET();
    HAL_Delay(5);
    __HAL_RCC_I2C1_RELEASE_RESET();
    I2C1_ClearBus();

    MX_I2C1_Init();

    MPU6050_Init();
    BMP580_Init();
    QMC5883L_Init();

    diag_i2c_recover++;
    Reset_Estimators();
}

/* ---------------------------- Меню ------------------------------------- */

typedef enum {
    MODE_NAV_MENU = 0,
    MODE_EDIT_LAT,
    MODE_EDIT_LON,
    MODE_FINISHED_OK,
    MODE_FINISHED_SKIP,
    MODE_CALIB_MENU,
    MODE_CALIB_RUNNING,
    MODE_FINISHED_ALL
} MenuMode_t;

typedef struct {
    int8_t  lat_sign;
    uint8_t lat_digits[4];

    int8_t  lon_sign;
    uint8_t lon_digits[5];

    uint8_t current_digit;
    uint8_t selected_option;
    MenuMode_t mode;
} LocationMenu_t;

static LocationMenu_t menu = {
    .lat_sign = 1,
    .lat_digits = {0, 0, 0, 0},
    .lon_sign = 1,
    .lon_digits = {0, 0, 0, 0, 0},
    .current_digit = 0,
    .selected_option = 0,
    .mode = MODE_NAV_MENU
};

void render_menu(void) {
    ssd1306_Fill(Black);

    ssd1306_SetCursor(0, 0);
    ssd1306_WriteString("Set Coordinates", Font_7x10, White);

    char str[10];

    ssd1306_SetCursor(0, 16);
    ssd1306_WriteString("Lat:", Font_6x8, White);

    snprintf(str, sizeof(str), "%c", (menu.lat_sign >= 0) ? '+' : '-');
    if (menu.mode == MODE_EDIT_LAT && menu.current_digit == 0) {
        ssd1306_FillRectangle(25, 15, 32, 24, White);
        ssd1306_SetCursor(26, 16);
        ssd1306_WriteString(str, Font_6x8, Black);
    } else {
        ssd1306_SetCursor(26, 16);
        ssd1306_WriteString(str, Font_6x8, White);
    }

    for (uint8_t i = 0; i < 4; i++) {
        if (i == 2) {
            ssd1306_SetCursor(50, 16);
            ssd1306_WriteString(".", Font_6x8, White);
        }

        snprintf(str, sizeof(str), "%d", menu.lat_digits[i]);
        uint8_t x_pos = 34 + (i * 8) + (i >= 2 ? 6 : 0);

        if (menu.mode == MODE_EDIT_LAT && menu.current_digit == (i + 1)) {
            ssd1306_FillRectangle(x_pos - 1, 15, x_pos + 6, 24, White);
            ssd1306_SetCursor(x_pos, 16);
            ssd1306_WriteString(str, Font_6x8, Black);
        } else {
            ssd1306_SetCursor(x_pos, 16);
            ssd1306_WriteString(str, Font_6x8, White);
        }
    }

    ssd1306_SetCursor(0, 28);
    ssd1306_WriteString("Lon:", Font_6x8, White);

    snprintf(str, sizeof(str), "%c", (menu.lon_sign >= 0) ? '+' : '-');
    if (menu.mode == MODE_EDIT_LON && menu.current_digit == 0) {
        ssd1306_FillRectangle(25, 27, 32, 36, White);
        ssd1306_SetCursor(26, 28);
        ssd1306_WriteString(str, Font_6x8, Black);
    } else {
        ssd1306_SetCursor(26, 28);
        ssd1306_WriteString(str, Font_6x8, White);
    }

    for (uint8_t i = 0; i < 5; i++) {
        if (i == 3) {
            ssd1306_SetCursor(58, 28);
            ssd1306_WriteString(".", Font_6x8, White);
        }

        snprintf(str, sizeof(str), "%d", menu.lon_digits[i]);
        uint8_t x_pos = 34 + (i * 8) + (i >= 3 ? 6 : 0);

        if (menu.mode == MODE_EDIT_LON && menu.current_digit == (i + 1)) {
            ssd1306_FillRectangle(x_pos - 1, 27, x_pos + 6, 36, White);
            ssd1306_SetCursor(x_pos, 28);
            ssd1306_WriteString(str, Font_6x8, Black);
        } else {
            ssd1306_SetCursor(x_pos, 28);
            ssd1306_WriteString(str, Font_6x8, White);
        }
    }

    if (menu.mode == MODE_NAV_MENU && menu.selected_option == 0) {
        ssd1306_FillRectangle(0, 52, 28, 63, White);
        ssd1306_SetCursor(6, 54);
        ssd1306_WriteString("Lat", Font_6x8, Black);
    } else {
        ssd1306_SetCursor(6, 54);
        ssd1306_WriteString("Lat", Font_6x8, White);
    }

    if (menu.mode == MODE_NAV_MENU && menu.selected_option == 1) {
        ssd1306_FillRectangle(32, 52, 60, 63, White);
        ssd1306_SetCursor(38, 54);
        ssd1306_WriteString("Lon", Font_6x8, Black);
    } else {
        ssd1306_SetCursor(38, 54);
        ssd1306_WriteString("Lon", Font_6x8, White);
    }

    if (menu.mode == MODE_NAV_MENU && menu.selected_option == 2) {
        ssd1306_FillRectangle(64, 52, 86, 63, White);
        ssd1306_SetCursor(70, 54);
        ssd1306_WriteString("OK", Font_6x8, Black);
    } else {
        ssd1306_SetCursor(70, 54);
        ssd1306_WriteString("OK", Font_6x8, White);
    }

    if (menu.mode == MODE_NAV_MENU && menu.selected_option == 3) {
        ssd1306_FillRectangle(90, 52, 127, 63, White);
        ssd1306_SetCursor(97, 54);
        ssd1306_WriteString("SKIP", Font_6x8, Black);
    } else {
        ssd1306_SetCursor(97, 54);
        ssd1306_WriteString("SKIP", Font_6x8, White);
    }

    ssd1306_UpdateScreen();
}

void update_encoder_value(void) {
    if (menu.mode == MODE_NAV_MENU) {
        if (encoder_val > 3) encoder_val = 3;
        if (encoder_val < 0) encoder_val = 0;
        menu.selected_option = encoder_val;
    }
    else if (menu.mode == MODE_EDIT_LAT) {
        if (menu.current_digit == 0) {
            if (encoder_val < 0) encoder_val = 0;
            if (encoder_val > 1) encoder_val = 1;
            menu.lat_sign = (encoder_val == 0) ? 1 : -1;
        }
        else if (menu.current_digit == 1) {
            if (encoder_val > 9) encoder_val = 9;
            if (encoder_val < 0) encoder_val = 0;
            menu.lat_digits[0] = encoder_val;
        }
        else if (menu.current_digit == 2) {
            uint8_t max_val = (menu.lat_digits[0] == 9) ? 0 : 9;
            if (encoder_val > max_val) encoder_val = max_val;
            if (encoder_val < 0) encoder_val = 0;
            menu.lat_digits[1] = encoder_val;
        }
        else {
            if (encoder_val > 9) encoder_val = 9;
            if (encoder_val < 0) encoder_val = 0;
            menu.lat_digits[menu.current_digit - 1] = encoder_val;
        }
    }
    else if (menu.mode == MODE_EDIT_LON) {
        if (menu.current_digit == 0) {
            if (encoder_val < 0) encoder_val = 0;
            if (encoder_val > 1) encoder_val = 1;
            menu.lon_sign = (encoder_val == 0) ? 1 : -1;
        }
        else if (menu.current_digit == 1) {
            if (encoder_val > 1) encoder_val = 1;
            if (encoder_val < 0) encoder_val = 0;
            menu.lon_digits[0] = encoder_val;
        }
        else if (menu.current_digit == 2) {
            uint8_t max_val = (menu.lon_digits[0] == 1) ? 8 : 9;
            if (encoder_val > max_val) encoder_val = max_val;
            if (encoder_val < 0) encoder_val = 0;
            menu.lon_digits[1] = encoder_val;
        }
        else if (menu.current_digit == 3) {
            uint8_t max_val = (menu.lon_digits[0] == 1 && menu.lon_digits[1] == 8) ? 0 : 9;
            if (encoder_val > max_val) encoder_val = max_val;
            if (encoder_val < 0) encoder_val = 0;
            menu.lon_digits[2] = encoder_val;
        }
        else {
            if (encoder_val > 9) encoder_val = 9;
            if (encoder_val < 0) encoder_val = 0;
            menu.lon_digits[menu.current_digit - 1] = encoder_val;
        }
    }

    render_menu();
}

void on_encoder_click(void) {
    if (menu.mode == MODE_NAV_MENU) {
        if (menu.selected_option == 0) {
            menu.mode = MODE_EDIT_LAT;
            menu.current_digit = 0;
            encoder_val = (menu.lat_sign >= 0) ? 0 : 1;
        } else if (menu.selected_option == 1) {
            menu.mode = MODE_EDIT_LON;
            menu.current_digit = 0;
            encoder_val = (menu.lon_sign >= 0) ? 0 : 1;
        } else if (menu.selected_option == 2) {
            menu.mode = MODE_FINISHED_OK;
        } else if (menu.selected_option == 3) {
            menu.mode = MODE_FINISHED_SKIP;
        }
    }
    else if (menu.mode == MODE_EDIT_LAT) {
        menu.current_digit++;
        if (menu.current_digit > 4) {
            menu.mode = MODE_NAV_MENU;
            encoder_val = menu.selected_option;
        } else {
            encoder_val = menu.lat_digits[menu.current_digit - 1];
            update_encoder_value();
            return;
        }
    }
    else if (menu.mode == MODE_EDIT_LON) {
        menu.current_digit++;
        if (menu.current_digit > 5) {
            menu.mode = MODE_NAV_MENU;
            encoder_val = menu.selected_option;
        } else {
            encoder_val = menu.lon_digits[menu.current_digit - 1];
            update_encoder_value();
            return;
        }
    }

    render_menu();
}

double get_final_latitude(void) {
    double val = (menu.lat_digits[0] * 10.0) +
                 (menu.lat_digits[1] * 1.0) +
                 (menu.lat_digits[2] * 0.1) +
                 (menu.lat_digits[3] * 0.01);
    if (val > 90.0) val = 90.0;
    return val * menu.lat_sign;
}

double get_final_longitude(void) {
    double val = (menu.lon_digits[0] * 100.0) +
                 (menu.lon_digits[1] * 10.0) +
                 (menu.lon_digits[2] * 1.0) +
                 (menu.lon_digits[3] * 0.1) +
                 (menu.lon_digits[4] * 0.01);
    if (val > 180.0) val = 180.0;
    return val * menu.lon_sign;
}

uint8_t check_encoder_button(void) {
    static uint32_t last_btn_press = 0;
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5) == GPIO_PIN_RESET) {
        if (HAL_GetTick() - last_btn_press > 250) {
            last_btn_press = HAL_GetTick();
            return 1;
        }
    }
    return 0;
}

static uint8_t calib_option = 0;

void render_calib_menu(void) {
    ssd1306_Fill(Black);

    ssd1306_SetCursor(0, 0);
    ssd1306_WriteString("Compass Calib", Font_7x10, White);

    ssd1306_SetCursor(0, 18);
    ssd1306_WriteString("Calibrate QMC5883L?", Font_6x8, White);

    if (calib_option == 0) {
        ssd1306_FillRectangle(10, 48, 58, 62, White);
        ssd1306_SetCursor(28, 51);
        ssd1306_WriteString("OK", Font_6x8, Black);
    } else {
        ssd1306_SetCursor(28, 51);
        ssd1306_WriteString("OK", Font_6x8, White);
    }

    if (calib_option == 1) {
        ssd1306_FillRectangle(70, 48, 118, 62, White);
        ssd1306_SetCursor(83, 51);
        ssd1306_WriteString("SKIP", Font_6x8, Black);
    } else {
        ssd1306_SetCursor(83, 51);
        ssd1306_WriteString("SKIP", Font_6x8, White);
    }

    ssd1306_UpdateScreen();
}

void render_calib_running(void) {
    ssd1306_Fill(Black);

    ssd1306_SetCursor(12, 4);
    ssd1306_WriteString("Calibrating...", Font_7x10, White);

    ssd1306_SetCursor(13, 20);
    ssd1306_WriteString("Rotate in 8-shape", Font_6x8, White);

    ssd1306_DrawCircle(64 - 8, 44, 7, White);
    ssd1306_DrawCircle(64 + 8, 44, 7, White);

    ssd1306_DrawCircle(64 - 8, 44, 6, White);
    ssd1306_DrawCircle(64 + 8, 44, 6, White);

    ssd1306_UpdateScreen();
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  {
      GPIO_InitTypeDef g = {0};
      __HAL_RCC_GPIOA_CLK_ENABLE();
      g.Pin  = GPIO_PIN_1;
      g.Mode = GPIO_MODE_INPUT;
      g.Pull = GPIO_PULLUP;
      HAL_GPIO_Init(GPIOA, &g);
  }

  HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
  __HAL_TIM_SET_COUNTER(&htim3, 0);

  HAL_Delay(50);
  MPU6050_Init();

  ssd1306_Init();
  ssd1306_Fill(Black);
  ssd1306_UpdateScreen();

  BMP580_Init();
  QMC5883L_Init();

  render_menu();
  int16_t menu_last_cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim3);
  uint32_t menu_last_tick = 0;

  while (menu.mode != MODE_FINISHED_OK && menu.mode != MODE_FINISHED_SKIP)
  {
      uint32_t now = HAL_GetTick();

      if (now - menu_last_tick >= 10) {
          menu_last_tick = now;
          int16_t current_cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim3);
          int16_t diff = current_cnt - menu_last_cnt;

          if (diff != 0) {
              int16_t steps = diff / 4;
              if (steps != 0) {
                  encoder_val += steps;
                  menu_last_cnt = current_cnt;
                  update_encoder_value();
              }
          }
      }

      if (check_encoder_button()) {
          on_encoder_click();
      }
  }

  if (menu.mode == MODE_FINISHED_OK) {
      latitude_deg    = get_final_latitude();
      longitude_deg   = get_final_longitude();
      latitude_deg_0  = latitude_deg;
      longitude_deg_0 = longitude_deg;
  } else {
      latitude_deg  = 0.0;
      longitude_deg = 0.0;
  }

  latitude_rad  = latitude_deg  * DEG2RAD_D;
  longitude_rad = longitude_deg * DEG2RAD_D;
  lat0_rad = latitude_rad;
  lon0_rad = longitude_rad;

  menu.mode = MODE_CALIB_MENU;
  encoder_val = 0;
  calib_option = 0;
  render_calib_menu();

  while (menu.mode == MODE_CALIB_MENU)
  {
      uint32_t now = HAL_GetTick();

      if (now - menu_last_tick >= 10) {
          menu_last_tick = now;
          int16_t current_cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim3);
          int16_t diff = current_cnt - menu_last_cnt;

          if (diff != 0) {
              int16_t steps = diff / 4;
              if (steps != 0) {
                  encoder_val += steps;
                  menu_last_cnt = current_cnt;

                  if (encoder_val > 1) encoder_val = 1;
                  if (encoder_val < 0) encoder_val = 0;

                  calib_option = encoder_val;
                  render_calib_menu();
              }
          }
      }

      if (check_encoder_button()) {
          if (calib_option == 0) {
              menu.mode = MODE_CALIB_RUNNING;
          } else {
              menu.mode = MODE_FINISHED_ALL;
          }
      }
  }

  if (menu.mode == MODE_CALIB_RUNNING) {
      render_calib_running();
      Calibrate_QMC5883L();
      menu.mode = MODE_FINISHED_ALL;
  }

  ssd1306_Fill(Black);
  ssd1306_SetCursor(20, 10);
  ssd1306_WriteString("System Ready!", Font_7x10, White);
  ssd1306_SetCursor(2, 30);
  ssd1306_WriteString("Set on level surface", Font_6x8, White);
  ssd1306_SetCursor(23, 48);
  ssd1306_WriteString("for IMU calib.", Font_6x8, White);
  ssd1306_UpdateScreen();
  HAL_Delay(10000);

  Calibrate_MPU6050();

  for (int i = 0; i < 20; i++) {
      if (Read_MPU6050() == HAL_OK) break;
      HAL_Delay(5);
  }
  Quaternion_From_Accel();

  mahony_twoKp = 2.0f * MAHONY_KP_ALIGN;
  {
      uint32_t t_prev = HAL_GetTick();
      for (int i = 0; i < 300; i++) {
          if (Read_MPU6050() == HAL_OK) {
              uint32_t t = HAL_GetTick();
              float d = (t - t_prev) * 0.001f;
              t_prev = t;
              if (d <= 0.0f || d > 0.05f) d = 0.005f;

              MahonyAHRSupdateIMU(gyro_X * DEG2RAD, gyro_Y * DEG2RAD, gyro_Z * DEG2RAD,
                                  accel_X, accel_Y, accel_Z, d);
          }
          HAL_Delay(3);
      }
  }
  mahony_twoKp = 2.0f * MAHONY_KP;

  {
      float p = 0.0f;
      for (int i = 0; i < 30 && !(p > 30000.0f && p < 110000.0f); i++) {
          p = BMP580_ReadPressure();
          HAL_Delay(10);
      }
      altitude_baro = (p > 30000.0f && p < 110000.0f) ? Pressure_To_Altitude(p) : 0.0f;
  }

  QMC5883L_Read(&mag_x, &mag_y, &mag_z, &heading_deg);

  kalman_altitude = altitude_baro;
  altitude_h      = altitude_baro;
  kalman_v_up     = 0.0f;
  kalman_yaw      = heading_deg;
  yaw             = heading_deg;

  v_E = 0.0f; v_N = 0.0f; v_Up = 0.0f;
  filtered_east = 0.0f; filtered_north = 0.0f; filtered_up = 0.0f;
  local_x = 0.0f; local_y = 0.0f;

  last_time = HAL_GetTick();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  int16_t last_cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim3);
  uint8_t  mpu_fail_streak = 0;
  uint8_t  baro_reject = 0;
  uint32_t last_encoder_tick = 0;
  uint32_t sensor_timer = 0;
  uint32_t bt_timer = 0;
  uint32_t oled_timer = 0;
  uint32_t btn1_down_tick = 0;
  uint8_t  btn1_down = 0, btn1_fired = 0;

  while (1)
    {
      uint32_t now = HAL_GetTick();
      if (now - last_time < 2) continue;
      float dt = (now - last_time) * 0.001f;
      last_time = now;

      if (dt > diag_max_dt) diag_max_dt = dt;
      if (dt > DT_MAX) dt = DT_MAX;

      if (now - last_encoder_tick >= 10) {
          last_encoder_tick = now;

          int16_t current_cnt = (int16_t)__HAL_TIM_GET_COUNTER(&htim3);
          int16_t diff = current_cnt - last_cnt;

          if (diff != 0) {
              int16_t steps = diff / 4;
              if (steps != 0) {
                  last_cnt = current_cnt;
                  if (steps > 0) current_screen = (current_screen + 1) % 3;
                  else           current_screen = (current_screen + 2) % 3;
              }
          }
      }

      if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1) == GPIO_PIN_RESET) {
          if (!btn1_down) { btn1_down = 1; btn1_down_tick = now; }
          else if (!btn1_fired && (now - btn1_down_tick) > 100) {
              btn1_fired = 1;
              Calibrate_MPU6050();
              Reset_Estimators();
              continue;
          }
      } else {
          btn1_down = 0;
          btn1_fired = 0;
      }

      if (Read_MPU6050() != HAL_OK) {
          diag_mpu_err++;
          if (++mpu_fail_streak >= 5) {
              Recover_I2C();
              mpu_fail_streak = 0;
          }
          continue;
      }
      mpu_fail_streak = 0;

      MahonyAHRSupdateIMU(gyro_X * DEG2RAD, gyro_Y * DEG2RAD, gyro_Z * DEG2RAD,
                          accel_X, accel_Y, accel_Z, dt);
      Compute_Nav_Accel();

      float accel_norm = sqrtf(accel_X * accel_X + accel_Y * accel_Y + accel_Z * accel_Z);
      float gyro_norm  = sqrtf(gyro_X * gyro_X + gyro_Y * gyro_Y + gyro_Z * gyro_Z);

      if (fabsf(accel_norm - 1.0f) < 0.08f && gyro_norm < 2.0f) {
          stationary_time += dt;
      } else {
          stationary_time = 0.0f;
      }
      uint8_t stationary = (stationary_time >= STATIONARY_TIME_S);

      if (stationary) {
          gyro_offset_X += 0.005f * gyro_X;
          gyro_offset_Y += 0.005f * gyro_Y;
          gyro_offset_Z += 0.005f * gyro_Z;
      }

      Yaw_Predict(gyro_Z, dt);
      Altitude_Predict(filtered_up, dt);

      if (now - sensor_timer >= 25) {
          sensor_timer = now;

          uint8_t forced_cmd = 0x1D;
          HAL_I2C_Mem_Write(&hi2c1, BMP580_I2C_ADDR, 0x37, I2C_MEMADD_SIZE_8BIT, &forced_cmd, 1, 10);
          float pressure_pa = BMP580_ReadPressure();

          if (pressure_pa > 30000.0f && pressure_pa < 110000.0f) {
              float alt = Pressure_To_Altitude(pressure_pa);
              if (fabsf(alt - kalman_altitude) < 50.0f || baro_reject > 20) {
                  altitude_baro = alt;
                  Altitude_Correct(alt);
                  baro_reject = 0;
              } else {
                  baro_reject++;
              }
          }

          if (QMC5883L_Read(&mag_x, &mag_y, &mag_z, &heading_deg) == HAL_OK) {
              Yaw_Correct(heading_deg);
          }
      }

      yaw        = kalman_yaw;
      altitude_h = kalman_altitude;
      v_Up       = kalman_v_up;
      if (stationary) { kalman_v_up = 0.0f; v_Up = 0.0f; }

      Update_Earth_Radii((float)latitude_rad, &R_N, &R_E);
      Calculate_W_g(v_E, v_N, altitude_h, (float)latitude_rad, R_E, R_N, &w_xi, &w_eta, &w_zeta);

      float sin_phi = sinf((float)latitude_rad);
      float cos_phi = cosf((float)latitude_rad);
      float Re_h = R_E + altitude_h;

      float dv_E = nav_e + (EARTH_U * sin_phi + w_zeta) * v_N - (2.0f * EARTH_U * cos_phi + v_E / Re_h) * v_Up;
      float dv_N = nav_n - (EARTH_U * sin_phi + w_zeta) * v_E - (v_N * v_Up) / Re_h;

      if (stationary) {
          v_E = 0.0f;
          v_N = 0.0f;
      } else {
          v_E += dv_E * dt;
          v_N += dv_N * dt;

          float decay = 1.0f - dt / VEL_DAMP_TAU_S;
          v_E *= decay;
          v_N *= decay;
      }

      Calculate_Coordinates(v_E, v_N, altitude_h, (float)latitude_rad, R_E, R_N,
                            &phi_dot, &lambda_dot, &altitude_dot);

      latitude_rad  += (double)phi_dot    * dt;
      longitude_rad += (double)lambda_dot * dt;

      if (latitude_rad >  1.5700) latitude_rad =  1.5700;
      if (latitude_rad < -1.5700) latitude_rad = -1.5700;
      if (longitude_rad >  3.14159265358979) longitude_rad -= 6.28318530717959;
      if (longitude_rad < -3.14159265358979) longitude_rad += 6.28318530717959;

      latitude_deg  = latitude_rad  * RAD2DEG_D;
      longitude_deg = longitude_rad * RAD2DEG_D;

      local_x = (float)((longitude_deg - longitude_deg_0) * 111139.0 * cos(latitude_rad));
      local_y = (float)((latitude_deg  - latitude_deg_0)  * 111139.0);

      Check_Health();

      if (now - bt_timer >= 50) {
          bt_timer = now;
          send_data_Bluetooth();
      }

      if (now - oled_timer >= 150) {
          oled_timer = now;

          ssd1306_Fill(Black);
          char str[30];

          if (current_screen == 0)
          {
              ssd1306_Line(0, 47, 128, 47, White);
              ssd1306_Line(64, 0, 64, 47, White);
              ssd1306_Line(42, 47, 42, 64, White);
              ssd1306_Line(84, 47, 84, 64, White);

              format_adaptive_float(str, sizeof(str), "X:", local_x);
              ssd1306_SetCursor(0, 52);
              ssd1306_WriteString(str, Font_6x8, White);

              format_adaptive_float(str, sizeof(str), "Y:", local_y);
              ssd1306_SetCursor(46, 52);
              ssd1306_WriteString(str, Font_6x8, White);

              format_adaptive_float(str, sizeof(str), "H:", altitude_h);
              ssd1306_SetCursor(89, 52);
              ssd1306_WriteString(str, Font_6x8, White);

              snprintf(str, sizeof(str), "Ve:%.1f", v_E);
              ssd1306_SetCursor(70, 0);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "Vn:%.1f", v_N);
              ssd1306_SetCursor(70, 16);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "Vh:%.1f", v_Up);
              ssd1306_SetCursor(70, 32);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "R:%.1f", roll);
              ssd1306_SetCursor(0, 0);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "P:%.1f", pitch);
              ssd1306_SetCursor(0, 16);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "Y:%.1f", yaw);
              ssd1306_SetCursor(0, 32);
              ssd1306_WriteString(str, Font_7x10, White);
          }
          else if (current_screen == 1)
          {
              snprintf(str, sizeof(str), "Lat: %.4f", latitude_deg);
              ssd1306_SetCursor(0, 0);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "Lon: %.4f", longitude_deg);
              ssd1306_SetCursor(0, 16);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "Head: %.1f deg", heading_deg);
              ssd1306_SetCursor(0, 32);
              ssd1306_WriteString(str, Font_7x10, White);

              snprintf(str, sizeof(str), "Baro H: %.1fm", altitude_baro);
              ssd1306_SetCursor(0, 48);
              ssd1306_WriteString(str, Font_7x10, White);
          }

          ssd1306_UpdateScreen();
      }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
