/*
 * I2C_DiagVars(): диагностика I2C через переменные (Live Expressions в STM32CubeIDE).
 * Ничего не выводит в UART и не зависит от ssd1306.
 *
 * Подключение в main.c:
 *   1) Добавьте файл в проект (Core/Src).  Если уже добавляли i2c_diag.c - уберите его из сборки.
 *   2) После MX_TIM3_Init() вызовите I2C_DiagVars();  (до MPU6050_Init() и ssd1306_Init(), не возвращается)
 *   3) Debug -> Resume, затем Window -> Show View -> Live Expressions, добавьте выражение:  dbg
 *      и раскройте структуру.
 *
 * dbg.verdict:
 *   0 = сканирование ещё идёт
 *   1 = SCL или SDA в 0 в покое  -> ЖЕЛЕЗО (нет подтяжек / замыкание на землю)
 *   2 = ни одного устройства     -> ЖЕЛЕЗО (питание, земля, SDA/SCL, не те пины)
 *   3 = нашлись не все           -> смотрите dbg.missing_mask (см. ниже)
 *   4 = нашлись все 4            -> железо OK, ищите проблему в коде / ssd1306_conf.h
 *
 * dbg.missing_mask (бит = устройства нет):  бит0=OLED  бит1=MPU6050  бит2=QMC5883L  бит3=BMP580
 */

#include "main.h"
#include "i2c.h"

#define DBG_SCL_PORT  GPIOB
#define DBG_SCL_PIN   GPIO_PIN_6
#define DBG_SDA_PORT  GPIOB
#define DBG_SDA_PIN   GPIO_PIN_7

typedef struct {
    /* итог */
    uint8_t  verdict;
    uint8_t  missing_mask;
    uint32_t scan_counter;      /* растёт каждый проход - значит программа жива */

    /* линии в покое (должно быть 1 и 1) */
    uint8_t  scl;
    uint8_t  sda;

    /* сканирование */
    uint8_t  found_count;       /* ожидается 4 */
    uint8_t  found_addr[16];    /* 7-битные адреса найденных устройств */

    /* наличие устройств */
    uint8_t  oled_ok;
    uint8_t  oled_addr;         /* 0x3C или 0x3D (в ssd1306_conf.h должен быть адрес << 1) */
    uint8_t  mpu_ok;
    uint8_t  qmc_ok;
    uint8_t  bmp_ok;
    uint8_t  bmp_addr;          /* 0x46 или 0x47 */

    /* чтение ID-регистров (0 - HAL_OK) */
    uint8_t  mpu_whoami;        /* ожидается 0x68 */
    uint8_t  qmc_id;            /* ожидается 0xFF */
    uint8_t  bmp_id;            /* ожидается 0x50 */
    uint8_t  mpu_read_st;
    uint8_t  qmc_read_st;
    uint8_t  bmp_read_st;

    /* состояние периферии I2C */
    uint8_t  bus_busy;          /* 1 - шина залипла (HAL_BUSY) */
    uint32_t reinit_count;      /* сколько раз пересоздавали I2C из-за BUSY */
    uint32_t i2c_error_code;    /* hi2c1.ErrorCode: 1=BERR 2=ARLO 4=AF(нет ACK) 8=OVR 0x20=TIMEOUT */
    uint32_t i2c_state;         /* HAL_I2C_GetState: 0x20=READY, 0x24=BUSY... */
} I2C_Dbg_t;

volatile I2C_Dbg_t dbg;

static uint8_t read_id(uint8_t a7, uint8_t reg, volatile uint8_t *val, volatile uint8_t *st)
{
    uint8_t v = 0;
    HAL_StatusTypeDef s = HAL_I2C_Mem_Read(&hi2c1, (uint16_t)(a7 << 1), reg,
                                           I2C_MEMADD_SIZE_8BIT, &v, 1, 50);
    *val = v;
    *st  = (uint8_t)s;
    return (s == HAL_OK);
}

void I2C_DiagVars(void)
{
    HAL_Delay(500);   /* дать датчикам запитаться */

    while (1) {
        dbg.verdict = 0;
        dbg.found_count = 0;
        dbg.oled_ok = dbg.mpu_ok = dbg.qmc_ok = dbg.bmp_ok = 0;
        dbg.oled_addr = dbg.bmp_addr = 0;
        dbg.mpu_whoami = dbg.qmc_id = dbg.bmp_id = 0;
        dbg.mpu_read_st = dbg.qmc_read_st = dbg.bmp_read_st = 0xFF;  /* 0xFF = не читали */
        dbg.bus_busy = 0;
        for (int i = 0; i < 16; i++) dbg.found_addr[i] = 0;

        /* 1. линии */
        dbg.scl = (uint8_t)HAL_GPIO_ReadPin(DBG_SCL_PORT, DBG_SCL_PIN);
        dbg.sda = (uint8_t)HAL_GPIO_ReadPin(DBG_SDA_PORT, DBG_SDA_PIN);

        /* 2. сканирование */
        for (uint8_t a = 0x08; a <= 0x77; a++) {
            HAL_StatusTypeDef st = HAL_I2C_IsDeviceReady(&hi2c1, (uint16_t)(a << 1), 2, 10);
            if (st == HAL_OK) {
                if (dbg.found_count < 16) dbg.found_addr[dbg.found_count] = a;
                dbg.found_count++;
                if (a == 0x3C || a == 0x3D) { dbg.oled_ok = 1; dbg.oled_addr = a; }
                if (a == 0x68 || a == 0x69) { dbg.mpu_ok  = 1; }
                if (a == 0x0D)              { dbg.qmc_ok  = 1; }
                if (a == 0x46 || a == 0x47) { dbg.bmp_ok  = 1; dbg.bmp_addr = a; }
            } else if (st == HAL_BUSY) {
                dbg.bus_busy = 1;
                break;
            }
        }

        /* 3. ID-регистры */
        if (dbg.mpu_ok) read_id(0x68, 0x75, &dbg.mpu_whoami, &dbg.mpu_read_st);
        if (dbg.qmc_ok) read_id(0x0D, 0x0D, &dbg.qmc_id,     &dbg.qmc_read_st);
        if (dbg.bmp_ok) read_id(dbg.bmp_addr, 0x01, &dbg.bmp_id, &dbg.bmp_read_st);

        /* 4. состояние периферии */
        dbg.i2c_error_code = hi2c1.ErrorCode;
        dbg.i2c_state      = (uint32_t)HAL_I2C_GetState(&hi2c1);

        /* 5. вердикт */
        dbg.missing_mask = (uint8_t)((!dbg.oled_ok) | ((!dbg.mpu_ok) << 1) |
                                     ((!dbg.qmc_ok) << 2) | ((!dbg.bmp_ok) << 3));
        if (!dbg.scl || !dbg.sda)        dbg.verdict = 1;
        else if (dbg.found_count == 0)   dbg.verdict = 2;
        else if (dbg.missing_mask != 0)  dbg.verdict = 3;
        else                             dbg.verdict = 4;

        /* если шина залипла - пересоздаём I2C и пробуем снова */
        if (dbg.bus_busy) {
            HAL_I2C_DeInit(&hi2c1);
            HAL_I2C_Init(&hi2c1);
            dbg.reinit_count++;
        }

        dbg.scan_counter++;
        HAL_Delay(500);
    }
}
